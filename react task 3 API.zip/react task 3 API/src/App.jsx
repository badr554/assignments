import React from 'react'
import { RouterProvider } from 'react-router-dom'
import { routing } from './components/Variables/Routing.jsx'

export default function App() {
  
  return (
    <div>
      <RouterProvider router={routing}/> ;
    


    </div>
  )
}
