import React from 'react'
import "../../Styles/Main.css"
export default function Home() {
  return (
    <div className='home'> home</div>
  )
}
