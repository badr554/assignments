 import { createBrowserRouter } from 'react-router-dom'
import Layout from '../Layout/Layout'
import Posts from '../../pages/Posts/Posts'
import Home from '../../pages/Home/home'
import SinglePost from '../Singlepost/SinglePost'
 export const routing = createBrowserRouter([
    {path:'/', element: <Layout/>,children:[
        { index: true , element: <Home/>},
        {path:'/posts', element: <Posts/>} ,
        {path:'/posts/:category/:id/:title', element: <SinglePost/>}
    ]}
  ])