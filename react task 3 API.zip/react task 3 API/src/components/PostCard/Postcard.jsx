import React from 'react'
import "../../Styles/Main.css"
import { Link } from 'react-router-dom'
export default function Postcard({title ,price, id , img}) {
  return (
    <Link to={`/posts/category/${id}/${title}`} className='postcard'>
        <img src={img} alt="" />
     <h4> {title}</h4>
     <p> Price: {price}</p>
     
    </Link>
  )
}
