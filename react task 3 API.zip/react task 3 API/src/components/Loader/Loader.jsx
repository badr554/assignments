import React from 'react'

export default function Loader() {
  return (
    <div>Loader</div>
  )
}
