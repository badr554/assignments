import React, { useEffect, useState } from 'react'
import Postcard from '../../components/PostCard/Postcard'
import "../../Styles/Main.css"
import Loader from '../../components/Loader/Loader'
import axios from "axios";
export default function Posts() {
    const [posts,setPosts] = useState([])
    const[loading,setLoading] = useState(true)
    const fetchApi = async ()=>{
        try{
          const res = await axios.get("https://fakestoreapi.com/products")   
             
             if(res.status!=200){
                setPosts([]) ; 
             }else{
                console.log(res)
                setPosts(res.data)
                setLoading(false)
             }
        }
        catch(err){
            
            console.log(err)
        }
      
    }
    useEffect(() => {
        fetchApi()
    }, [])
  return (
    <div className='PostContainer'>
        {loading && <Loader/>}
     {posts?.map((Post)=> <Postcard key={Post.id} title = {Post.title} price ={Post.price } id= {Post.id} img= {Post.image} />) }
    </div>
  )
}
