import React, { useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { useState } from 'react'
import "../../Styles/Main.css"
import Loader from '../Loader/Loader'
import axios from "axios";
export default function SinglePost() {
    const {id} = useParams()
    const [data,setData] = useState([])
    const [loading,setLoading] = useState(true)
    const fetchapi = async ()=>{
        try{
            const res = await axios.get(`https://fakestoreapi.com/products/${id}`); 
            
            if(res.status!=200){
                setData([])
            }
            else{ 
                setData(res.data);
                setLoading(false)}
        }
     catch(err){
            console.log(err)
        }
   
    }

    useEffect(()=>{
        fetchapi() 
    },[])
  return (
    <div class ="singlepost"> 
    {loading && <Loader/>}
    <div className="card">
    <img src={data.image} alt="" />
    <div className="details">
   <h2>{data.title} </h2>
   <p> ${data.price} </p>
   <input type="nnumber" class="quantity" value={1} />
   <button>Add to cart</button>
   <h3> Produc Details </h3>
   <p class="desc" >  {data.description}</p>
   </div>
   </div>
    </div>
  )
}
