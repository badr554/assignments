import React from 'react'
import "../../Styles/Main.css"
import { NavLink } from 'react-router-dom'
export default function Navbar() {
  return (
    <div className='Nav'>
        <ul>
            <li>
                <NavLink   to={"/"}>Home</NavLink>
                <NavLink to={"/posts"}>Posts</NavLink>
            </li>
        </ul>
    </div>
  )
}
