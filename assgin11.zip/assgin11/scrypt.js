let x = document.querySelector(".container");
let cards = [{
    img:  "images/image.png" , 
    title: "Perfected Strategies for you" , 
    description:"Lorem ipsum dolor sit amet consectetur.Id est convallis neque elementum"} , {
        img:  "images/image.png" , 
        title: "Perfected Strategies for you" , 
        description:"Lorem ipsum dolor sit amet consectetur.Id est convallis neque elementum"} ,{
            img:  "images/image.png" , 
            title: "Perfected Strategies for you" , 
            description:"Lorem ipsum dolor sit amet consectetur.Id est convallis neque elementum"}
] 
cards.forEach((y)=>{
    x.innerHTML+= `<div class="cards">
    <div class="images">
        <img src="${y.img}" alt="">
    </div>
    <div class="logo">
        <img src=" images/logo.png" alt="">
    </div>
    <div class="descreption">
        <h2>${y.title}</h2>
        <p>${y.description}</p>
    </div>`
} )