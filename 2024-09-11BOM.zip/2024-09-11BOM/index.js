const checkConnection = () => {
    const isOnline = navigator.onLine;
    if (isOnline) {
        return;
    } else {
        document.body.textContent = "Is Offline";
    }
};
checkConnection();

const cursor = document.querySelector(".custom_cursor");
window.addEventListener("mousemove", (e) => {
    cursor.style.left = e.clientX - 20 + "px";
    cursor.style.top = e.clientY - 20 + "px";
});

const sections = document.querySelectorAll("section");
const navLinks = document.querySelectorAll(".nav_links a");
const scrollToTopBtn = document.querySelector(".scrollToTop");

window.addEventListener("scroll", () => {
    const windowScrollY = window.scrollY;
    sections.forEach((section) => {
        const sectionId = section.getAttribute("id");
        const sectionOffsetTop = section.offsetTop;
        navLinks.forEach((link) => {
            const linkRef = link.getAttribute("href").slice(1);
            if (windowScrollY >= sectionOffsetTop) {
                if (sectionId === linkRef) {
                    link.classList.add("current");
                    document.title = `BOM | ${sectionId.toUpperCase()}`;
                } else {
                    link.classList.remove("current");
                }
            }
        });
    });

    if (windowScrollY >= 100) {
        scrollToTopBtn.classList.add("active");
    } else {
        scrollToTopBtn.classList.remove("active");
    }
});

scrollToTopBtn.addEventListener("click", () => {
    scrollTo({
        top: 0,
    });
});

window.addEventListener("blur", () => {
    document.title = `BOM | BROWSER 😒`;
});
const initialTitle = document.title;
window.addEventListener("focus", () => {
    document.title = `${initialTitle}`;
});

const loadingScreen = document.querySelector(".loading_screen");
const loaderCounter = loadingScreen.children[1];
let counter = 0;
function intervalCounter() {
    const interval = setInterval(() => {
        counter++;
        if (counter == 100) {
            clearInterval(interval);
            loadingScreen.classList.add("hiddenLoader");
            loadingScreen.children[0].classList.add("hiddenTitle");
            loadingScreen.children[1].classList.add("hiddenTitle");
        }
        loaderCounter.textContent = `${counter}%`;
    }, 50);
}
intervalCounter();

let time = document.getElementById("current_time");
setInterval(() => {
    let d = new Date();
    time.innerHTML = d.toLocaleTimeString();
}, 1000);
