let check = document.querySelector(".formstyle input");
let p = document.querySelector(".formstyle p");
check.oninput = () => {
    if (check.value.length < 6) {
        check.classList.add("inputAlert");
        p.classList.add("appear");
    } else {
        p.classList.remove("appear");
        check.classList.remove("inputAlert");
    }
};